import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';

const surahs = Array.from({ length: 114 }, (_, i) => ({
  id: i + 1,
  name: `سورة ${i + 1}`,
  type: i < 7 ? 'root' : i < 36 ? 'trunk' : i < 100 ? 'branch' : 'leaf',
}));

const links = surahs.map((surah, i) => ({
  source: surah.id,
  target: (i * 13 + 7) % 114 + 1,
}));

function OliveTreeNetwork() {
  const svgRef = useRef();

  useEffect(() => {
    const width = 1000;
    const height = 1000;
    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .style('background', '#0c0f1a');

    const simulation = d3.forceSimulation(surahs)
      .force('link', d3.forceLink(links).id(d => d.id).distance(d => d.source < 10 ? 120 : 50))
      .force('charge', d3.forceManyBody().strength(-90))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('y', d3.forceY().strength(0.1).y(d => {
        switch (d.type) {
          case 'root': return height * 0.95;
          case 'trunk': return height * 0.65;
          case 'branch': return height * 0.35;
          case 'leaf': return height * 0.1;
        }
      }))
      .force('x', d3.forceX().strength(0.06));

    const link = svg.append('g')
      .attr('stroke', '#82d6ff33')
      .selectAll('line')
      .data(links)
      .join('line')
      .attr('stroke-width', 1);

    const node = svg.append('g')
      .attr('stroke', '#fff')
      .attr('stroke-width', 0.5)
      .selectAll('circle')
      .data(surahs)
      .join('circle')
      .attr('r', d => {
        switch (d.type) {
          case 'root': return 9;
          case 'trunk': return 7;
          case 'branch': return 5;
          case 'leaf': return 3.5;
        }
      })
      .attr('fill', d => {
        switch (d.type) {
          case 'root': return '#d1fa99';
          case 'trunk': return '#9fffe2';
          case 'branch': return '#69c9ff';
          case 'leaf': return '#3efcbf';
        }
      })
      .call(drag(simulation));

    node.append('title').text(d => d.name);

    simulation.on('tick', () => {
      link
        .attr('x1', d => d.source.x)
        .attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x)
        .attr('y2', d => d.target.y);

      node
        .attr('cx', d => d.x)
        .attr('cy', d => d.y);
    });
  }, []);

  function drag(simulation) {
    return d3.drag()
      .on('start', (event, d) => {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        d.fx = d.x;
        d.fy = d.y;
      })
      .on('drag', (event, d) => {
        d.fx = event.x;
        d.fy = event.y;
      })
      .on('end', (event, d) => {
        if (!event.active) simulation.alphaTarget(0);
        d.fx = null;
        d.fy = null;
      });
  }

  return <svg ref={svgRef} width="100%" height="100%" />;
}

function LandingPage({ onEnter }) {
  return (
    <div style={{ textAlign: 'center', padding: '80px', background: '#f0f0f0', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2.5rem', color: '#2c3e50' }}>🌙 الشبكة القرآنية الرقمية</h1>
      <p style={{ fontSize: '1.25rem', margin: '20px 0', maxWidth: '600px', marginInline: 'auto' }}>
        مشروع تكنولوجي هندسي يتتبع أثر الحرف من نقطة الباء حتى آخر المصحف، على هيئة شجرة زيتون مباركة 🧬⚡️
      </p>
      <button onClick={onEnter} style={{ padding: '12px 30px', fontSize: '18px', background: '#2ecc71', color: 'white', border: 'none', borderRadius: '8px', cursor: 'pointer' }}>
        🚪 دخول إلى الشبكة
      </button>
    </div>
  );
}

export default function App() {
  const [entered, setEntered] = useState(false);
  return entered ? <OliveTreeNetwork /> : <LandingPage onEnter={() => setEntered(true)} />;
}